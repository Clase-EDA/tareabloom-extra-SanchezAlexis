/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bloomfilter;

import java.util.*;


/**
 *
 * @author Alexis Sánchez
 */
public class Prueba {
    Bloom bf;
    public int numDatos;
    public int[]numeros;
    public int cantNumeros;
    
    public Prueba(int numDatos, int numHash, int tamañoArreglo){
        this.numDatos=numDatos;
        bf=new Bloom(numDatos,numHash,tamañoArreglo);
        cantNumeros=0;
        numeros=new int[numDatos];
    }
    
    public void generaNumerosRandom(){
        Random r=new Random();
        int n;
        for (int i = 0; i < numDatos; i++){
            n=r.nextInt(1000);
            numeros[i]=n;
        }
        insertaNumeros();
    }
    
    public void insertaNumeros(){
        for (int i = 0; i < numDatos; i++) {
            bf.inserta(numeros[i]);
        }
    }
    
    public void llaves(){
        System.out.println("\nTamaño del filtro: "+bf.getNumLlaves());
        bf.getLlaves();
    }
    public void numHash(){
        System.out.println("Numero de funciones Hash: "+bf.numHash);
    }
    
    public void imprimeFiltro(){
        boolean[]filter;
        
        filter=bf.getFilter();
        for (int i = 0; i < bf.m; i++) {
            System.out.print("\npos ["+i+"]: "+filter[i]);
        }
    }
    
    public void calculaFalsosPositivos(){
        Random r=new Random();
        int j, n;
        double numExist=0;
        int tamaño=numDatos/2;
        int[]numRand=new int[tamaño];
        double f;
        
        for (int i = 0; i < tamaño; i++) {
            n=r.nextInt(500);
            numRand[i]=n;
        }
        
        for (int i = 0; i < tamaño; i++) {
            if(bf.existe(numRand[i]))
                numExist++;
        }
        
        f=numExist/numRand.length;
        System.out.println("Probabilidad de Falsos Positivos: "+f);
    }
            
}

















































