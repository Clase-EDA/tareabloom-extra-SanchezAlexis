
package bloomfilter;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Alexis Sánchez
 */
public class Bloom {
    public boolean[]filter;
    public int numElem;
    public double f;
    public int numHash;
    public ArrayList<Integer>llaves;
    public int limite;
    public int numLlaves=0;
    public int m;
    
    public Bloom(int numElem,int numHash, int m){
        this.numElem=numElem;
        this.numHash=numHash;
        this.limite=numElem*2;
        this.m=m;
        
        filter=new boolean[m];
        
        for (int i = 0; i < limite; i++) {
            filter[i]=false;
        }
        llaves=new ArrayList();
    }
    
    public void inserta(int numero){
        int llave;
        for (int i = 0; i < numHash; i++) {
            llave=hash2(numero,i);
            
            if(llave<m){
                filter[llave]=true;
                numLlaves++;
                llaves.add(llave);
            }
        }
    }
    
    public boolean existe(int num){
        int llave;
        for (int i = 0; i < numHash; i++) {
            llave=hash2(num,i);
            if (filter[llave]==false){
                return false;
            }
        }
        return true;
    }
    
    public int funcionHash(int num,int pos){
        char ch[];
        String x=Integer.toString(num);
        ch = x.toCharArray();
        int xlength = x.length();

        int i, sum;
        for (sum=0, i=0; i < xlength; i++)
            sum += ch[i];
        return (sum % (m+pos));
    }
    public static int hash2(int key, int pos)
    {
        key = ~key + (key << 15); // key = (key << 15) - key - 1;
        key = key ^ (key >>> 12);
        key = key + (key << 2);
        key = key ^ (key >>> 4);
        key = key * 2057; // key = (key + (key << 3)) + (key << 11);
        key = key ^ (key >>> 16);
        
        pos = ~pos + (pos << 15); // key = (key << 15) - key - 1;
        pos = pos ^ (pos >>> 12);
        pos = pos + (pos << 2);
        pos = pos ^ (pos >>> 4);
        pos = pos * 2057; // key = (key + (key << 3)) + (key << 11);
        pos = pos ^ (pos >>> 16);
        
        return Math.abs(key/1000000)+Math.abs(pos/1000000);
    }
    
    public boolean[]getFilter(){
        return filter;
    }
    public int getNumLlaves(){
        return numLlaves;
    }
    public void getLlaves(){
        System.out.println(llaves.toString());
    }
   
}



























































